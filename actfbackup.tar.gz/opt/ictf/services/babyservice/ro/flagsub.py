from swpag_client import Team

t = Team("http://actf0-thu.cse365.io/", "CLopKWAozg3JhGwBRs1v")

while True:
	flag = input()
	if (flag == "end"):
		break;
	flags = [""]
	flags.append(flag)
	var = t.submit_flag(flags)
	print(var)
