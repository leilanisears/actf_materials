from swpag_client import Team

t = Team("http://actf0-thu.cse365.io/", "CLopKWAozg3JhGwBRs1v")


print(t.get_game_status()) # get game status

#t.get_service_list() # get service list

#t.get_targets(service_id) # get teams ip etc.

