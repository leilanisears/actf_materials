import sys
from swpag_client import Team

t = Team("http://actf1-thu.rev.fish/", "0IXjCqbjCGMq7UBi7Q7Z")

flags = sys.argv[1:]

print(t.submit_flag(flags))
