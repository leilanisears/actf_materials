#! /usr/bin/env bash

cd /home/chall/service/rw && ../ro/mommyservice
